# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging

from flag_gems.ops.sort import sort_stable

logger = logging.getLogger(__name__)


def argsort(inp, dim=-1, descending=False):
    """Returns the indices that sort a tensor along a given dimension.

    This is equivalent to calling torch.sort and returning only the indices.
    """
    logger.debug("GEMS ARGSORT")
    _, indices = sort_stable(inp, stable=True, dim=dim, descending=descending)
    return indices
